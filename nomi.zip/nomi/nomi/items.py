# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Item,Field


class NomiItem(Item):
    
    name = Field()
    location = Field()
    website = Field()
    address = Field()
    phone_number = Field()
    type_of_coach = Field()
    description = Field()
    qualification = Field()
    image = Field()
    url = Field()

    pass
