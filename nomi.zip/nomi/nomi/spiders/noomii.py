from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import NomiItem

#from datetime import date


class NoomiiSpider(CrawlSpider):

    name = "noomii"

    start_urls = [
                "https://www.noomii.com/life-coaches"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".pagination li:last-child a"]))),
        Rule(LinkExtractor(restrict_css=("div.info h4 a")),callback="coach"),  
    )


    def coach(self, response):

        coaches = NomiItem()

        coaches["name"] = response.css(".coach-name span[itemprop='name']::text").extract_first()

        if coaches["name"] == None:
            return

        coaches["location"] = response.css(".coach-name h1 small::text").extract_first()

        if coaches["location"]:
            coaches["location"] = coaches["location"].strip()

        coaches["website"] = response.css(".contact a[target='_blank']::attr(href)").extract_first()

        coaches["address"] = response.css(".contact h3+ li::text").extract()

        if coaches["address"]:
            coaches["address"] = "".join(coaches["address"])
            coaches["address"] = coaches["address"].strip()
        
        coaches["phone_number"] = response.css(".contact li:nth-child(3)::text").extract()

        if coaches["phone_number"]:
            coaches["phone_number"] = "".join(coaches["phone_number"])
            coaches["phone_number"] = coaches["phone_number"].strip()
        
        if not ("+" in coaches["phone_number"] or "-" in coaches["phone_number"]):
            for num in range(0,10):
                if str(num) in coaches["phone_number"]:
                    break
                if num == 9:
                    coaches["phone_number"] = None
        
        coaches["type_of_coach"] = response.css(".profile meta::attr(content)").extract_first()

        coaches["description"] = response.css(".summary::text").extract_first()

        if coaches["description"]:
            coaches["description"] = coaches["description"].replace('"'," ")

        coaches["qualification"] = response.css(".text-muted::text").extract_first()
        if coaches["qualification"]:
            coaches["qualification"] = coaches["qualification"].replace('"'," ")

        coaches["image"] = response.css(".avatar img::attr(src)").extract_first()

        coaches["url"] = response.url



        # a = open("a.txt","w")
        # a.writelines(response.text)

        yield coaches
 