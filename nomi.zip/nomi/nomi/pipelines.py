# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don"t forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import sqlite3

class NomiPipeline(object):

    def __init__(self):
        self.create_connection()
        self.create_table()
        pass

    def create_connection(self):
        self.conn = sqlite3.connect("noomii.db")
        self.curr = self.conn.cursor()

    def create_table(self):
        self.curr.execute(" drop table if exists coaches")
        self.curr.execute(" drop table if exists product")

        self.curr.execute("create table coaches(name text,location text,website text,address text,phone_number text,type_of_coach text,description text,qualification text,image text,url text)")

    def store_db(self,coaches):

        if coaches["name"]:
            self.curr.execute(f'insert into coaches values("{coaches["name"]}","{coaches["location"]}","{coaches["website"]}","{coaches["address"]}","{coaches["phone_number"]}","{coaches["type_of_coach"]}","{coaches["description"]}","{coaches["qualification"]}","{coaches["image"]}","{coaches["url"]}")')

        self.conn.commit()

    def process_item(self, item, spider):
        self.store_db(item)
        return item
